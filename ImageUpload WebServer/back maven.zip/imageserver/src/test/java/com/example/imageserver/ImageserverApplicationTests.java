package com.example.imageserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
